let products = [
  {
    "img": "img/apple.jpeg",
    "name": "Apple",
    "price": "1.25"
  },
  {
    "img": "img/banana.jpeg",
    "name": "Banana",
    "price": "1.05"
  },
  {
    "img": "img/stawberry.jpeg",
    "name": "Strawberry",
    "price": "1.55"
  },
  {
    "img": "img/watermelon.jpeg",
    "name": "Watermelon",
    "price": "1.99"
  }
];

export default products;